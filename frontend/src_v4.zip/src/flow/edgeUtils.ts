import {
  addEdge,
  MarkerType,
  type Connection,
  type Edge,
} from "reactflow";

export function edgeAlreadyExists(
  edges: Edge[],
  params: Connection
) {

  return edges.some(
    (edge) =>
      (
        edge.source === params.source &&
        edge.target === params.target
      ) ||

      (
        edge.source === params.target &&
        edge.target === params.source
      )
  );
}

export function createUpdatedEdges(
  edges: Edge[],
  params: Connection
) {
  return addEdge(
    {
      ...params,
      style: {
        strokeWidth: 3,   // Makes the line thicker/bolder
        stroke: '#333',   // Makes the line a dark, solid gray/black
      },
      // 2. Style the Arrowhead
      markerEnd: {
        type: MarkerType.ArrowClosed,
        width: 20,        // Makes the arrow head wider
        height: 20,       // Makes the arrow head taller
        color: '#333',    // Matches the arrow head to the dark line color
      },
    },
    edges
  );
}